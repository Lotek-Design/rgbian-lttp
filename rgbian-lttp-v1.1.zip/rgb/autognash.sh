!#/bin/bash
/usr/bin/gnash --fullscreen /home/pi/rgb/rgb.swf exit 0
