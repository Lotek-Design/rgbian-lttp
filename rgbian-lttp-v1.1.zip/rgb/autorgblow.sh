#!/bin/bash
sudo /home/pi/rpi-fb-matrix/rpi-fb-matrix --led-slowdown-gpio=2 --led-brightness=20 --led-pwm-lsb-nanoseconds=300 --led-pwm-bits=9 --led-gpio-mapping=adafruit-hat-pwm /home/pi/rpi-fb-matrix/matrix.cfg

exit
