#!/bin/bash
/usr/bin/python /home/pi/rgb/autolight.py
exit 0
